# Smart Textile Flutter App - Installation Guide

## 📱 Complete Flutter App Ready!

Your Flutter app is fully configured with:
- ✅ Modern Material Design UI with green theme
- ✅ Real-time sensor data monitoring
- ✅ Interactive charts and data visualization
- ✅ Manual relay control
- ✅ Automatic threshold management
- ✅ Data export functionality
- ✅ Provider-based state management
- ✅ Comprehensive error handling

## Prerequisites

1. **Flutter SDK**: Install Flutter from [flutter.dev](https://flutter.dev/docs/get-started/install)
2. **Android Studio** or **VS Code** with Flutter extensions
3. **Android device** or **iOS device** for testing

## Quick Start (3 Steps)

### 1. Install Dependencies
\`\`\`bash
# Navigate to project directory
cd smart_textile_app

# Install Flutter dependencies
flutter pub get

# Generate JSON serialization code
flutter packages pub run build_runner build
\`\`\`

### 2. Configure Your Server
Edit `lib/services/api_service.dart` and update line 7:
\`\`\`dart
static const String baseUrl = 'http://YOUR_SERVER_IP:3000';
\`\`\`

**Find your server IP:**
- Windows: `ipconfig`
- Mac/Linux: `ifconfig`
- Use your local network IP (e.g., 192.168.1.100)

### 3. Run the App
\`\`\`bash
# Connect your device or start emulator
flutter run
\`\`\`

## App Features

### 🏠 Home Screen
- Current temperature and humidity readings
- Relay status indicator
- Connection status monitoring
- Real-time data updates every 5 seconds

### 📊 Monitoring Screen
- Interactive charts showing sensor trends
- DS18B20 and DHT22 temperature tracking
- Humidity monitoring with dual y-axis
- Historical data visualization

### 🎛️ Control Screen
- Manual relay ON/OFF buttons
- Automatic threshold settings
- Temperature and humidity limits
- Auto-control enable/disable toggle

### 📋 Data Screen
- View stored historical readings
- Export data as CSV files
- Share functionality for data analysis
- Refresh stored data from server

## Troubleshooting

### Connection Issues
1. **"No internet connection"**: Ensure phone and server are on same WiFi
2. **"Connection failed"**: Check server is running on port 3000
3. **"API timeout"**: Verify server IP address is correct

### Build Issues
\`\`\`bash
# Clean and rebuild
flutter clean
flutter pub get
flutter packages pub run build_runner build --delete-conflicting-outputs
\`\`\`

### Data Issues
1. **No charts showing**: Wait 2-3 minutes for data to accumulate
2. **Relay not responding**: Check ESP32 connection to server
3. **Export not working**: Ensure server has stored data

## Development Commands

\`\`\`bash
# Hot reload development
flutter run --hot

# Build release APK
flutter build apk --release

# Build for iOS (Mac only)
flutter build ios --release

# Clean project
flutter clean

# Update dependencies
flutter pub upgrade
\`\`\`

## Network Setup

### Server Requirements
- Web server running on port 3000
- ESP32 connected and sending data
- All devices on same WiFi network

### Firewall Settings
- Allow incoming connections on port 3000
- Ensure mobile device can reach server IP

## App Architecture

\`\`\`
lib/
├── main.dart                 # App entry point with Provider setup
├── models/
│   ├── sensor_data.dart      # Data models with JSON serialization
│   └── sensor_data.g.dart    # Generated serialization code
├── providers/
│   └── sensor_provider.dart  # State management with auto-polling
├── screens/
│   ├── home_screen.dart      # Main dashboard with navigation
│   ├── monitoring_screen.dart # Charts and data visualization
│   ├── control_screen.dart   # Relay control and thresholds
│   └── data_screen.dart      # Historical data and export
├── services/
│   └── api_service.dart      # HTTP client for backend API
├── theme/
│   └── app_theme.dart        # Material Design theme
├── utils/
│   └── constants.dart        # App configuration constants
└── widgets/                  # Reusable UI components
\`\`\`

## Ready to Use!

Your Flutter app is complete and production-ready. Simply update the server IP address and run `flutter pub get` followed by `flutter run` to start monitoring your smart textile system on mobile!

## Support

If you need help:
1. Check Flutter doctor: `flutter doctor`
2. Verify server is accessible from mobile device
3. Ensure ESP32 is sending data to server
4. Check network connectivity between all devices
