import { NextResponse } from "next/server"

// GET endpoint - ESP32 requests current configuration
export async function GET() {
  try {
    // In production, fetch from database
    const config = {
      tempThreshold: 30.0,
      humidityThreshold: 70.0,
      updateInterval: 5000, // milliseconds
      serverUrl: process.env.NEXT_PUBLIC_SERVER_URL || "http://localhost:3000",
      timestamp: new Date().toISOString(),
    }

    return NextResponse.json(config)
  } catch (error) {
    console.error("Error fetching ESP32 config:", error)
    return NextResponse.json({ error: "Failed to fetch configuration" }, { status: 500 })
  }
}
