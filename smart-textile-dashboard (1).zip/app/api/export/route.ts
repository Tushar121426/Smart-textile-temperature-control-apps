import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Generate CSV data for the last 24 hours
    const now = Date.now()
    const csvLines = ["timestamp,ds18b20,dhtTemp,dhtHum"]

    for (let i = 24; i >= 0; i--) {
      const timestamp = now - i * 60 * 60 * 1000
      const timeOfDay = (timestamp / (1000 * 60 * 60)) % 24

      const baseTemp = 22 + Math.sin(((timeOfDay - 6) * Math.PI) / 12) * 5
      const ds18b20 = baseTemp + (Math.random() - 0.5) * 2
      const dhtTemp = baseTemp + (Math.random() - 0.5) * 2
      const dhtHum = 45 + Math.sin((timeOfDay * Math.PI) / 12) * 20 + (Math.random() - 0.5) * 10

      csvLines.push(
        `${timestamp},${Math.round(ds18b20 * 10) / 10},${Math.round(dhtTemp * 10) / 10},${Math.round(Math.max(20, Math.min(80, dhtHum)) * 10) / 10}`,
      )
    }

    const csvContent = csvLines.join("\n")

    return new NextResponse(csvContent, {
      headers: {
        "Content-Type": "text/csv",
        "Content-Disposition": "attachment; filename=sensor_data.csv",
      },
    })
  } catch (error) {
    console.error("Error generating CSV export:", error)
    return NextResponse.json({ error: "Failed to generate CSV export" }, { status: 500 })
  }
}
