import { NextResponse } from "next/server"

// Health check endpoint for ESP32 to verify server connectivity
export async function GET() {
  return NextResponse.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    server: "Smart Textile Control Panel API",
  })
}
