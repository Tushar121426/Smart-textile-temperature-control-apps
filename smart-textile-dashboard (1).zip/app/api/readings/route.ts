import { NextResponse } from "next/server"
import { getRelayState } from "../../../lib/relay-state"

// In-memory storage for sensor data and history
let currentSensorData = {
  timestamp: Date.now(),
  ds18b20: 25.0,
  dhtTemp: 24.8,
  dhtHum: 45.0,
  relay: false,
}

const sensorHistory: any[] = []

export async function GET() {
  try {
    // Generate realistic mock data that changes over time
    const now = Date.now()
    const timeOfDay = (now / (1000 * 60 * 60)) % 24 // Hour of day

    // Simulate daily temperature variation
    const baseTemp = 22 + Math.sin(((timeOfDay - 6) * Math.PI) / 12) * 5
    const ds18b20 = baseTemp + (Math.random() - 0.5) * 2
    const dhtTemp = baseTemp + (Math.random() - 0.5) * 2
    const dhtHum = 45 + Math.sin((timeOfDay * Math.PI) / 12) * 20 + (Math.random() - 0.5) * 10

    currentSensorData = {
      timestamp: now,
      ds18b20: Math.round(ds18b20 * 10) / 10,
      dhtTemp: Math.round(dhtTemp * 10) / 10,
      dhtHum: Math.round(Math.max(20, Math.min(80, dhtHum)) * 10) / 10,
      relay: getRelayState(),
    }

    // Add to history (keep last 200 readings)
    sensorHistory.push({ ...currentSensorData })
    if (sensorHistory.length > 200) {
      sensorHistory.shift()
    }

    return NextResponse.json({
      ...currentSensorData,
      history: sensorHistory.slice(-40), // Return last 40 for chart
    })
  } catch (error) {
    console.error("Error fetching readings:", error)
    return NextResponse.json({ error: "Failed to fetch readings" }, { status: 500 })
  }
}
