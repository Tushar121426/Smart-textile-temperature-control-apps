import { type NextRequest, NextResponse } from "next/server"
import { getRelayState, setRelayState } from "../../../lib/relay-state"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    if (typeof body.relay !== "boolean") {
      return NextResponse.json({ error: "Invalid relay state" }, { status: 400 })
    }

    setRelayState(body.relay)
    console.log("Relay state updated to:", body.relay)

    return NextResponse.json({
      success: true,
      relay: getRelayState(),
      message: `Relay turned ${getRelayState() ? "ON" : "OFF"}`,
    })
  } catch (error) {
    console.error("Error controlling relay:", error)
    return NextResponse.json({ error: "Failed to control relay" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({ relay: getRelayState() })
}
