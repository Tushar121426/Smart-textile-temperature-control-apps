import { type NextRequest, NextResponse } from "next/server"

// In-memory storage for sensor data (in production, use a database)
let currentSensorData = {
  ds18b20Temp: 25.0,
  dhtTemp: 24.8,
  humidity: 45.0,
  relayStatus: false,
  timestamp: new Date().toISOString(),
}

// GET endpoint - Dashboard requests current sensor data
export async function GET() {
  try {
    return NextResponse.json(currentSensorData)
  } catch (error) {
    console.error("Error fetching sensor data:", error)
    return NextResponse.json({ error: "Failed to fetch sensor data" }, { status: 500 })
  }
}

// POST endpoint - ESP32 sends sensor data updates
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate incoming data
    if (
      typeof body.ds18b20Temp !== "number" ||
      typeof body.dhtTemp !== "number" ||
      typeof body.humidity !== "number" ||
      typeof body.relayStatus !== "boolean"
    ) {
      return NextResponse.json({ error: "Invalid sensor data format" }, { status: 400 })
    }

    // Update sensor data with timestamp
    currentSensorData = {
      ds18b20Temp: body.ds18b20Temp,
      dhtTemp: body.dhtTemp,
      humidity: body.humidity,
      relayStatus: body.relayStatus,
      timestamp: new Date().toISOString(),
    }

    console.log("Sensor data updated:", currentSensorData)

    return NextResponse.json({
      success: true,
      message: "Sensor data updated successfully",
    })
  } catch (error) {
    console.error("Error updating sensor data:", error)
    return NextResponse.json({ error: "Failed to update sensor data" }, { status: 500 })
  }
}
