import { type NextRequest, NextResponse } from "next/server"

// In-memory storage for threshold (in production, use a database)
let temperatureThreshold = 30.0

// GET endpoint - Get current threshold
export async function GET() {
  try {
    return NextResponse.json({
      threshold: temperatureThreshold,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error fetching threshold:", error)
    return NextResponse.json({ error: "Failed to fetch threshold" }, { status: 500 })
  }
}

// POST endpoint - Update temperature threshold
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate threshold value
    if (typeof body.threshold !== "number" || body.threshold < 0 || body.threshold > 100) {
      return NextResponse.json({ error: "Invalid threshold value. Must be between 0 and 100." }, { status: 400 })
    }

    temperatureThreshold = body.threshold

    console.log("Temperature threshold updated to:", temperatureThreshold)

    return NextResponse.json({
      success: true,
      threshold: temperatureThreshold,
      message: "Threshold updated successfully",
    })
  } catch (error) {
    console.error("Error updating threshold:", error)
    return NextResponse.json({ error: "Failed to update threshold" }, { status: 500 })
  }
}
