import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Generate mock historical data for the last 24 hours
    const now = Date.now()
    const historicalData = []

    for (let i = 24; i >= 0; i--) {
      const timestamp = now - i * 60 * 60 * 1000 // Every hour
      const timeOfDay = (timestamp / (1000 * 60 * 60)) % 24

      // Simulate daily temperature variation
      const baseTemp = 22 + Math.sin(((timeOfDay - 6) * Math.PI) / 12) * 5
      const ds18b20 = baseTemp + (Math.random() - 0.5) * 2
      const dhtTemp = baseTemp + (Math.random() - 0.5) * 2
      const dhtHum = 45 + Math.sin((timeOfDay * Math.PI) / 12) * 20 + (Math.random() - 0.5) * 10

      historicalData.push({
        timestamp,
        ds18b20: Math.round(ds18b20 * 10) / 10,
        dhtTemp: Math.round(dhtTemp * 10) / 10,
        dhtHum: Math.round(Math.max(20, Math.min(80, dhtHum)) * 10) / 10,
      })
    }

    return NextResponse.json(historicalData)
  } catch (error) {
    console.error("Error fetching stored data:", error)
    return NextResponse.json({ error: "Failed to fetch stored data" }, { status: 500 })
  }
}
