import { type NextRequest, NextResponse } from "next/server"

// In-memory threshold storage
let thresholds = {
  temp: 30.0,
  hum: 70.0,
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    if (typeof body.temp !== "number" || typeof body.hum !== "number") {
      return NextResponse.json({ error: "Invalid threshold values" }, { status: 400 })
    }

    if (body.temp < 0 || body.temp > 100 || body.hum < 0 || body.hum > 100) {
      return NextResponse.json({ error: "Thresholds must be between 0 and 100" }, { status: 400 })
    }

    thresholds = {
      temp: body.temp,
      hum: body.hum,
    }

    console.log("Thresholds updated:", thresholds)

    return NextResponse.json({
      success: true,
      thresholds,
      message: "Thresholds saved successfully",
    })
  } catch (error) {
    console.error("Error saving thresholds:", error)
    return NextResponse.json({ error: "Failed to save thresholds" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json(thresholds)
}
