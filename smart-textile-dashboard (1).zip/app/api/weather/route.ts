import { NextResponse } from "next/server"

// Cache weather data to avoid excessive API calls
let cachedWeatherData: any = null
let lastFetchTime = 0
const CACHE_DURATION = 5 * 60 * 1000 // 5 minutes in milliseconds

export async function GET() {
  try {
    const now = Date.now()

    // Return cached data if it's still fresh
    if (cachedWeatherData && now - lastFetchTime < CACHE_DURATION) {
      return NextResponse.json(cachedWeatherData)
    }

    // Get API key from environment variables
    const apiKey = process.env.OPENWEATHER_API_KEY
    const city = process.env.WEATHER_CITY || "Dhaka" // Default to Dhaka as in original demo

    if (!apiKey) {
      console.warn("OpenWeatherMap API key not found. Using mock data.")

      // Return mock weather data if no API key is provided
      const mockData = {
        location: city,
        temperature: 28.5,
        condition: "partly cloudy",
        description: "Partly cloudy with light winds",
        timestamp: new Date().toISOString(),
        source: "mock",
      }

      return NextResponse.json(mockData)
    }

    // Fetch weather data from OpenWeatherMap API
    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`

    const response = await fetch(weatherUrl, {
      next: { revalidate: 300 }, // Cache for 5 minutes
    })

    if (!response.ok) {
      throw new Error(`Weather API responded with status: ${response.status}`)
    }

    const weatherData = await response.json()

    // Transform the API response to match our interface
    const transformedData = {
      location: weatherData.name,
      temperature: Math.round(weatherData.main.temp * 10) / 10, // Round to 1 decimal
      condition: weatherData.weather[0].main.toLowerCase(),
      description: weatherData.weather[0].description,
      timestamp: new Date().toISOString(),
      source: "openweathermap",
      // Additional data that might be useful
      humidity: weatherData.main.humidity,
      pressure: weatherData.main.pressure,
      windSpeed: weatherData.wind?.speed || 0,
    }

    // Cache the transformed data
    cachedWeatherData = transformedData
    lastFetchTime = now

    console.log("Weather data fetched successfully for:", city)

    return NextResponse.json(transformedData)
  } catch (error) {
    console.error("Error fetching weather data:", error)

    // Return fallback data on error
    const fallbackData = {
      location: "Unknown",
      temperature: 0,
      condition: "unavailable",
      description: "Weather data temporarily unavailable",
      timestamp: new Date().toISOString(),
      source: "fallback",
      error: true,
    }

    return NextResponse.json(fallbackData, { status: 200 }) // Return 200 to avoid breaking the UI
  }
}
