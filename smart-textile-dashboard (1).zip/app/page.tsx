"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Script from "next/script"

interface SensorData {
  timestamp: number
  ds18b20: number
  dhtTemp: number
  dhtHum: number
  relay: boolean
  history?: Array<{
    ts: number
    ds: number
    dt: number
    dh: number
  }>
}

export default function SmartTextileDashboard() {
  const [activeTab, setActiveTab] = useState("home")
  const [sensorData, setSensorData] = useState<SensorData>({
    timestamp: Date.now(),
    ds18b20: 0,
    dhtTemp: 0,
    dhtHum: 0,
    relay: false,
    history: [],
  })
  const [tempThreshold, setTempThreshold] = useState(30)
  const [humThreshold, setHumThreshold] = useState(70)
  const [autoControl, setAutoControl] = useState(false)
  const [storedData, setStoredData] = useState("No data yet.")
  const [chartLoaded, setChartLoaded] = useState(false)
  const chartRef = useRef<any>(null)
  const chartInstanceRef = useRef<any>(null)

  // Initialize Chart.js when script loads
  const initChart = () => {
    if (typeof window !== "undefined" && (window as any).Chart && chartRef.current && !chartInstanceRef.current) {
      const ctx = chartRef.current.getContext("2d")
      chartInstanceRef.current = new (window as any).Chart(ctx, {
        type: "line",
        data: {
          labels: [],
          datasets: [
            {
              label: "DS18B20 (°C)",
              data: [],
              borderColor: "rgb(255,99,132)",
              tension: 0.2,
              fill: false,
            },
            {
              label: "DHT Temp (°C)",
              data: [],
              borderColor: "rgb(255,159,64)",
              tension: 0.2,
              fill: false,
            },
            {
              label: "Humidity (%)",
              data: [],
              borderColor: "rgb(54,162,235)",
              tension: 0.2,
              yAxisID: "y2",
              fill: false,
            },
          ],
        },
        options: {
          responsive: true,
          interaction: { mode: "index", intersect: false },
          scales: {
            y: {
              position: "left",
              title: { display: true, text: "Temp (°C)" },
            },
            y2: {
              position: "right",
              title: { display: true, text: "Humidity (%)" },
              grid: { drawOnChartArea: false },
              min: 0,
              max: 100,
            },
          },
        },
      })
      setChartLoaded(true)
    }
  }

  // Update chart with new data
  const updateChart = (data: SensorData) => {
    if (chartInstanceRef.current && data.history) {
      const labels = data.history.map((h) => new Date(h.ts).toLocaleTimeString())
      chartInstanceRef.current.data.labels = labels
      chartInstanceRef.current.data.datasets[0].data = data.history.map((h) => h.ds)
      chartInstanceRef.current.data.datasets[1].data = data.history.map((h) => h.dt)
      chartInstanceRef.current.data.datasets[2].data = data.history.map((h) => h.dh)
      chartInstanceRef.current.update()
    }
  }

  // Fetch sensor data
  const fetchSensorData = async () => {
    try {
      const response = await fetch("/api/readings")
      if (response.ok) {
        const data = await response.json()
        setSensorData(data)
        updateChart(data)

        // Auto control logic
        if (autoControl) {
          if (data.ds18b20 >= tempThreshold || data.dhtHum >= humThreshold) {
            if (!data.relay) await sendRelay(true)
          } else {
            if (data.relay) await sendRelay(false)
          }
        }
      }
    } catch (error) {
      console.error("Error fetching sensor data:", error)
    }
  }

  // Send relay command
  const sendRelay = async (on: boolean) => {
    try {
      const response = await fetch("/api/relay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ relay: on }),
      })
      if (response.ok) {
        fetchSensorData() // Refresh data
      }
    } catch (error) {
      console.error("Error controlling relay:", error)
    }
  }

  // Save thresholds
  const saveThresholds = async () => {
    try {
      const response = await fetch("/api/thresholds", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ temp: tempThreshold, hum: humThreshold }),
      })
      if (response.ok) {
        alert("Thresholds saved successfully!")
      }
    } catch (error) {
      console.error("Error saving thresholds:", error)
      alert("Failed to save thresholds")
    }
  }

  // Refresh stored data
  const refreshStored = async () => {
    try {
      const response = await fetch("/api/stored")
      if (response.ok) {
        const data = await response.json()
        const lines = data.map(
          (item: any) =>
            `${new Date(item.timestamp).toLocaleString()}, ${item.ds18b20}, ${item.dhtTemp}, ${item.dhtHum}`,
        )
        setStoredData(lines.join("\n") || "No data stored yet.")
      }
    } catch (error) {
      console.error("Error fetching stored data:", error)
      setStoredData("Failed to fetch stored data.")
    }
  }

  // Export CSV
  const exportCSV = async () => {
    try {
      const response = await fetch("/api/export")
      if (response.ok) {
        const csvData = await response.text()
        const blob = new Blob([csvData], { type: "text/csv" })
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = "sensor_data.csv"
        a.click()
        URL.revokeObjectURL(url)
      }
    } catch (error) {
      console.error("Error exporting CSV:", error)
      alert("Export failed")
    }
  }

  useEffect(() => {
    fetchSensorData()
    const interval = setInterval(fetchSensorData, 5000)
    return () => clearInterval(interval)
  }, [autoControl, tempThreshold, humThreshold])

  useEffect(() => {
    if (chartLoaded) {
      const dataInterval = setInterval(refreshStored, 60000)
      return () => clearInterval(dataInterval)
    }
  }, [chartLoaded])

  return (
    <>
      <Script src="https://cdn.jsdelivr.net/npm/chart.js" onLoad={initChart} />

      <div
        className="min-h-screen"
        style={{
          fontFamily: 'Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial',
          background: "#f6f8fb",
          color: "#222",
        }}
      >
        {/* Header */}
        <header style={{ background: "#2f9e44", color: "#fff", padding: "1rem", textAlign: "center" }}>
          <h1 style={{ margin: 0, fontSize: "1.5rem", fontWeight: "bold" }}>Smart Textile — Temp & Humidity</h1>
        </header>

        {/* Navigation */}
        <nav
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "0.5rem",
            padding: "0.75rem",
            background: "#fff",
            borderBottom: "1px solid #e6e9ee",
          }}
        >
          {[
            { id: "home", label: "Home" },
            { id: "monitor", label: "Monitoring" },
            { id: "control", label: "Temperature Control" },
            { id: "data", label: "Weather Data Center" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                background: activeTab === tab.id ? "#2f9e44" : "transparent",
                color: activeTab === tab.id ? "#fff" : "#333",
                border: "1px solid #ddd",
                borderColor: activeTab === tab.id ? "#2f9e44" : "#ddd",
                padding: "0.5rem 0.8rem",
                cursor: "pointer",
                borderRadius: "6px",
              }}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        {/* Main Content */}
        <main style={{ padding: "1.25rem", maxWidth: "1000px", margin: "0 auto" }}>
          {/* Home Tab */}
          {activeTab === "home" && (
            <div>
              <h2 style={{ marginBottom: "1rem" }}>Overview</h2>
              <p style={{ marginBottom: "1rem" }}>
                This app displays your fabric sensors (DS18B20 + DHT22), lets you toggle the Peltier relay, set
                thresholds, and view/export stored readings.
              </p>

              <div style={{ display: "flex", gap: "1rem", marginTop: "1rem", flexWrap: "wrap" }}>
                <Card
                  style={{
                    background: "#fff",
                    flex: "1 1 200px",
                    padding: "1rem",
                    borderRadius: "8px",
                    boxShadow: "0 6px 18px rgba(20,20,40,0.04)",
                  }}
                >
                  <CardHeader style={{ padding: 0, marginBottom: "0.5rem" }}>
                    <CardTitle style={{ fontSize: "1rem", margin: 0 }}>Current Temperature</CardTitle>
                  </CardHeader>
                  <CardContent style={{ padding: 0 }}>
                    <div style={{ fontSize: "1.8rem", marginTop: "0.5rem", color: "#2f9e44" }}>
                      {sensorData.ds18b20.toFixed(1)} °C
                    </div>
                  </CardContent>
                </Card>

                <Card
                  style={{
                    background: "#fff",
                    flex: "1 1 200px",
                    padding: "1rem",
                    borderRadius: "8px",
                    boxShadow: "0 6px 18px rgba(20,20,40,0.04)",
                  }}
                >
                  <CardHeader style={{ padding: 0, marginBottom: "0.5rem" }}>
                    <CardTitle style={{ fontSize: "1rem", margin: 0 }}>Current Humidity</CardTitle>
                  </CardHeader>
                  <CardContent style={{ padding: 0 }}>
                    <div style={{ fontSize: "1.8rem", marginTop: "0.5rem", color: "#2f9e44" }}>
                      {sensorData.dhtHum.toFixed(1)} %
                    </div>
                  </CardContent>
                </Card>

                <Card
                  style={{
                    background: "#fff",
                    flex: "1 1 200px",
                    padding: "1rem",
                    borderRadius: "8px",
                    boxShadow: "0 6px 18px rgba(20,20,40,0.04)",
                  }}
                >
                  <CardHeader style={{ padding: 0, marginBottom: "0.5rem" }}>
                    <CardTitle style={{ fontSize: "1rem", margin: 0 }}>Relay Status</CardTitle>
                  </CardHeader>
                  <CardContent style={{ padding: 0 }}>
                    <div style={{ fontSize: "1.8rem", marginTop: "0.5rem", color: "#2f9e44" }}>
                      {sensorData.relay ? "ON" : "OFF"}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Monitoring Tab */}
          {activeTab === "monitor" && (
            <div>
              <h2 style={{ marginBottom: "1rem" }}>Temperature & Humidity Monitoring</h2>

              <div
                style={{
                  display: "flex",
                  gap: "1rem",
                  justifyContent: "space-between",
                  flexWrap: "wrap",
                  marginBottom: "1rem",
                }}
              >
                <div>
                  DS18B20 Temp: <strong>{sensorData.ds18b20.toFixed(1)}</strong> °C
                </div>
                <div>
                  DHT22 Temp: <strong>{sensorData.dhtTemp.toFixed(1)}</strong> °C
                </div>
                <div>
                  DHT22 Humidity: <strong>{sensorData.dhtHum.toFixed(1)}</strong> %
                </div>
              </div>

              <div
                style={{
                  background: "#fff",
                  borderRadius: "8px",
                  padding: "0.75rem",
                  boxShadow: "0 6px 18px rgba(20,20,40,0.04)",
                }}
              >
                <canvas ref={chartRef} height="120"></canvas>
              </div>
            </div>
          )}

          {/* Control Tab */}
          {activeTab === "control" && (
            <div>
              <h2 style={{ marginBottom: "1rem" }}>Temperature Control System</h2>

              <div style={{ background: "#fff", padding: "1rem", borderRadius: "8px", marginBottom: "1rem" }}>
                <label style={{ display: "block", marginBottom: "0.5rem" }}>
                  Current Relay Status: <span style={{ color: "#2f9e44" }}>{sensorData.relay ? "ON" : "OFF"}</span>
                </label>
                <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.5rem" }}>
                  <Button
                    onClick={() => sendRelay(true)}
                    style={{
                      background: "#2f9e44",
                      color: "#fff",
                      border: "none",
                      padding: "0.6rem 0.9rem",
                      borderRadius: "6px",
                      cursor: "pointer",
                    }}
                  >
                    Turn Peltier ON
                  </Button>
                  <Button
                    onClick={() => sendRelay(false)}
                    style={{
                      background: "#6c757d",
                      color: "#fff",
                      border: "none",
                      padding: "0.6rem 0.9rem",
                      borderRadius: "6px",
                      cursor: "pointer",
                    }}
                  >
                    Turn Peltier OFF
                  </Button>
                </div>
              </div>

              <div style={{ background: "#fff", padding: "1rem", borderRadius: "8px", marginBottom: "1rem" }}>
                <h3 style={{ marginBottom: "0.5rem" }}>Automatic Control Thresholds</h3>
                <label style={{ display: "block", margin: "0.4rem 0" }}>
                  Temperature threshold (°C):
                  <Input
                    type="number"
                    step="0.1"
                    value={tempThreshold}
                    onChange={(e) => setTempThreshold(Number(e.target.value))}
                    style={{ width: "120px", padding: "0.3rem", marginLeft: "0.5rem" }}
                  />
                </label>
                <label style={{ display: "block", margin: "0.4rem 0" }}>
                  Humidity threshold (%):
                  <Input
                    type="number"
                    step="1"
                    value={humThreshold}
                    onChange={(e) => setHumThreshold(Number(e.target.value))}
                    style={{ width: "120px", padding: "0.3rem", marginLeft: "0.5rem" }}
                  />
                </label>
                <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.5rem" }}>
                  <Button
                    onClick={saveThresholds}
                    style={{
                      background: "#2f9e44",
                      color: "#fff",
                      border: "none",
                      padding: "0.6rem 0.9rem",
                      borderRadius: "6px",
                      cursor: "pointer",
                    }}
                  >
                    Save thresholds
                  </Button>
                  <Button
                    onClick={() => setAutoControl(!autoControl)}
                    style={{
                      background: "#6c757d",
                      color: "#fff",
                      border: "none",
                      padding: "0.6rem 0.9rem",
                      borderRadius: "6px",
                      cursor: "pointer",
                    }}
                  >
                    {autoControl ? "Disable" : "Enable"} Auto Control
                  </Button>
                </div>
                <p style={{ marginTop: "0.5rem" }}>
                  Auto control: <strong>{autoControl ? "ON" : "OFF"}</strong>
                </p>
              </div>
            </div>
          )}

          {/* Data Tab */}
          {activeTab === "data" && (
            <div>
              <h2 style={{ marginBottom: "1rem" }}>Weather Data Center</h2>

              <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.5rem" }}>
                <Button
                  onClick={refreshStored}
                  style={{
                    background: "#2f9e44",
                    color: "#fff",
                    border: "none",
                    padding: "0.6rem 0.9rem",
                    borderRadius: "6px",
                    cursor: "pointer",
                  }}
                >
                  Refresh Stored Data
                </Button>
                <Button
                  onClick={exportCSV}
                  style={{
                    background: "#6c757d",
                    color: "#fff",
                    border: "none",
                    padding: "0.6rem 0.9rem",
                    borderRadius: "6px",
                    cursor: "pointer",
                  }}
                >
                  Export CSV
                </Button>
              </div>

              <pre
                style={{
                  background: "#fff",
                  padding: "1rem",
                  minHeight: "200px",
                  borderRadius: "8px",
                  overflow: "auto",
                  boxShadow: "0 6px 18px rgba(20,20,40,0.04)",
                  whiteSpace: "pre-wrap",
                  fontSize: "0.875rem",
                }}
              >
                {storedData}
              </pre>
            </div>
          )}
        </main>

        {/* Footer */}
        <footer style={{ textAlign: "center", padding: "1rem", color: "#666", marginTop: "2rem" }}>
          <small>ESP32 Smart Textile — Frontend</small>
        </footer>
      </div>
    </>
  )
}
