// Configuration file for ESP32 Smart Textile Controller
// Copy this file and rename to config.h, then update with your settings

#ifndef CONFIG_H
#define CONFIG_H

// ---------- WiFi Configuration ----------
// Replace with your WiFi network credentials
#define WIFI_SSID "YOUR_WIFI_SSID"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"

// ---------- Server Configuration ----------
// Replace with your server URL
// For local development: "http://192.168.1.100:3000" (use your computer's IP)
// For production: "https://your-app.vercel.app"
#define SERVER_URL "http://192.168.1.100:3000"

// ---------- Hardware Configuration ----------
// GPIO pin assignments (modify if using different pins)
#define DS18B20_PIN 4      // DS18B20 temperature sensor data pin
#define DHT22_PIN 5        // DHT22 temperature/humidity sensor data pin
#define RELAY_PIN 16       // Relay control pin for Peltier element
#define STATUS_LED_PIN 2   // Built-in LED for status indication

// ---------- Sensor Configuration ----------
#define DHT_TYPE DHT22     // DHT sensor type (DHT22 or DHT11)

// ---------- Timing Configuration ----------
#define SENSOR_READ_INTERVAL 2000    // How often to read sensors (ms)
#define DATA_SEND_INTERVAL 5000      // How often to send data to server (ms)
#define CONFIG_FETCH_INTERVAL 30000  // How often to fetch config from server (ms)
#define WIFI_TIMEOUT 20000           // WiFi connection timeout (ms)

// ---------- Default Thresholds ----------
// These will be overridden by server configuration
#define DEFAULT_TEMP_THRESHOLD 30.0      // Default temperature threshold (°C)
#define DEFAULT_HUMIDITY_THRESHOLD 70.0  // Default humidity threshold (%)

// ---------- Connection Settings ----------
#define MAX_RECONNECT_ATTEMPTS 5    // Maximum WiFi reconnection attempts
#define HTTP_TIMEOUT 10000          // HTTP request timeout (ms)

// ---------- Debug Settings ----------
#define SERIAL_BAUD_RATE 115200     // Serial monitor baud rate
#define ENABLE_DEBUG_OUTPUT true    // Enable detailed debug output

#endif // CONFIG_H
