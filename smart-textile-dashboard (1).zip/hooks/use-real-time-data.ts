"use client"

import { useState, useEffect, useRef, useCallback } from "react"

interface SensorData {
  ds18b20Temp: number
  dhtTemp: number
  humidity: number
  relayStatus: boolean
  timestamp: string
}

interface ConnectionStatus {
  isConnected: boolean
  lastUpdate: string
  error: string | null
  reconnectAttempts: number
}

export function useRealTimeData() {
  const [sensorData, setSensorData] = useState<SensorData>({
    ds18b20Temp: 0,
    dhtTemp: 0,
    humidity: 0,
    relayStatus: false,
    timestamp: new Date().toISOString(),
  })

  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>({
    isConnected: false,
    lastUpdate: "",
    error: null,
    reconnectAttempts: 0,
  })

  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const maxReconnectAttempts = 5
  const pollingInterval = 2000 // Poll every 2 seconds

  const fetchSensorData = useCallback(async () => {
    try {
      const response = await fetch("/api/sensor", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      setSensorData(data)
      setConnectionStatus((prev) => ({
        ...prev,
        isConnected: true,
        lastUpdate: new Date().toISOString(),
        error: null,
        reconnectAttempts: 0,
      }))
    } catch (error) {
      console.error("Error fetching sensor data:", error)
      setConnectionStatus((prev) => ({
        ...prev,
        isConnected: false,
        error: error instanceof Error ? error.message : "Failed to fetch data",
        reconnectAttempts: prev.reconnectAttempts + 1,
      }))
    }
  }, [])

  const connect = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
    }

    // Initial fetch
    fetchSensorData()

    // Set up polling
    intervalRef.current = setInterval(fetchSensorData, pollingInterval)

    console.log("Started HTTP polling for sensor data")
  }, [fetchSensorData])

  const disconnect = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
    setConnectionStatus((prev) => ({
      ...prev,
      isConnected: false,
      error: null,
    }))
    console.log("Stopped HTTP polling")
  }, [])

  const manualReconnect = useCallback(() => {
    console.log("Manual reconnect requested")
    setConnectionStatus((prev) => ({
      ...prev,
      reconnectAttempts: 0,
      error: null,
    }))
    connect()
  }, [connect])

  useEffect(() => {
    connect()

    return () => {
      disconnect()
    }
  }, [connect, disconnect])

  return {
    sensorData,
    connectionStatus,
    manualReconnect,
    disconnect,
  }
}
