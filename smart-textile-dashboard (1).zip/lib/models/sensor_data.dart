import 'package:json_annotation/json_annotation.dart';

part 'sensor_data.g.dart';

@JsonSerializable()
class SensorData {
  final int timestamp;
  final double ds18b20;
  final double dhtTemp;
  final double dhtHum;
  final bool relay;
  final List<HistoryPoint>? history;

  SensorData({
    required this.timestamp,
    required this.ds18b20,
    required this.dhtTemp,
    required this.dhtHum,
    required this.relay,
    this.history,
  });

  factory SensorData.fromJson(Map<String, dynamic> json) =>
      _$SensorDataFromJson(json);

  Map<String, dynamic> toJson() => _$SensorDataToJson(this);
}

@JsonSerializable()
class HistoryPoint {
  final int ts;
  final double ds;
  final double dt;
  final double dh;

  HistoryPoint({
    required this.ts,
    required this.ds,
    required this.dt,
    required this.dh,
  });

  factory HistoryPoint.fromJson(Map<String, dynamic> json) =>
      _$HistoryPointFromJson(json);

  Map<String, dynamic> toJson() => _$HistoryPointToJson(this);
}

@JsonSerializable()
class ThresholdSettings {
  final double tempThreshold;
  final double humThreshold;

  ThresholdSettings({
    required this.tempThreshold,
    required this.humThreshold,
  });

  factory ThresholdSettings.fromJson(Map<String, dynamic> json) =>
      _$ThresholdSettingsFromJson(json);

  Map<String, dynamic> toJson() => _$ThresholdSettingsToJson(this);
}
