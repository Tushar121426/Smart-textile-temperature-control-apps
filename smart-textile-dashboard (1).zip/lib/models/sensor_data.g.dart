// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sensor_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SensorData _$SensorDataFromJson(Map<String, dynamic> json) => SensorData(
      timestamp: json['timestamp'] as int,
      ds18b20: (json['ds18b20'] as num).toDouble(),
      dhtTemp: (json['dhtTemp'] as num).toDouble(),
      dhtHum: (json['dhtHum'] as num).toDouble(),
      relay: json['relay'] as bool,
      history: (json['history'] as List<dynamic>?)
          ?.map((e) => HistoryPoint.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$SensorDataToJson(SensorData instance) =>
    <String, dynamic>{
      'timestamp': instance.timestamp,
      'ds18b20': instance.ds18b20,
      'dhtTemp': instance.dhtTemp,
      'dhtHum': instance.dhtHum,
      'relay': instance.relay,
      'history': instance.history,
    };

HistoryPoint _$HistoryPointFromJson(Map<String, dynamic> json) => HistoryPoint(
      ts: json['ts'] as int,
      ds: (json['ds'] as num).toDouble(),
      dt: (json['dt'] as num).toDouble(),
      dh: (json['dh'] as num).toDouble(),
    );

Map<String, dynamic> _$HistoryPointToJson(HistoryPoint instance) =>
    <String, dynamic>{
      'ts': instance.ts,
      'ds': instance.ds,
      'dt': instance.dt,
      'dh': instance.dh,
    };

ThresholdSettings _$ThresholdSettingsFromJson(Map<String, dynamic> json) =>
    ThresholdSettings(
      tempThreshold: (json['tempThreshold'] as num).toDouble(),
      humThreshold: (json['humThreshold'] as num).toDouble(),
    );

Map<String, dynamic> _$ThresholdSettingsToJson(ThresholdSettings instance) =>
    <String, dynamic>{
      'tempThreshold': instance.tempThreshold,
      'humThreshold': instance.humThreshold,
    };
