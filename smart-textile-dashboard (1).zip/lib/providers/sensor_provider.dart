import 'dart:async';
import 'package:flutter/material.dart';
import '../models/sensor_data.dart';
import '../services/api_service.dart';

class SensorProvider extends ChangeNotifier {
  final ApiService _apiService = ApiService();
  
  // Current sensor data
  SensorData? _currentData;
  SensorData? get currentData => _currentData;

  // Connection status
  bool _isConnected = false;
  bool get isConnected => _isConnected;

  // Loading states
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  // Error handling
  String? _error;
  String? get error => _error;

  // Auto control settings
  bool _autoControlEnabled = false;
  bool get autoControlEnabled => _autoControlEnabled;

  double _tempThreshold = 30.0;
  double get tempThreshold => _tempThreshold;

  double _humThreshold = 70.0;
  double get humThreshold => _humThreshold;

  // Polling timer
  Timer? _pollingTimer;

  SensorProvider() {
    _startPolling();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    super.dispose();
  }

  // Start polling for sensor data
  void _startPolling() {
    _pollingTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      fetchSensorData();
    });
    // Initial fetch
    fetchSensorData();
  }

  // Fetch current sensor data
  Future<void> fetchSensorData() async {
    try {
      _error = null;
      if (_currentData == null) {
        _isLoading = true;
        notifyListeners();
      }

      final data = await _apiService.getReadings();
      _currentData = data;
      _isConnected = true;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isConnected = false;
      _isLoading = false;
      notifyListeners();
    }
  }

  // Manual relay control
  Future<bool> controlRelay(bool state) async {
    try {
      _error = null;
      final success = await _apiService.setRelay(state);
      if (success) {
        // Update local state immediately for better UX
        if (_currentData != null) {
          _currentData = SensorData(
            timestamp: _currentData!.timestamp,
            ds18b20: _currentData!.ds18b20,
            dhtTemp: _currentData!.dhtTemp,
            dhtHum: _currentData!.dhtHum,
            relay: state,
            history: _currentData!.history,
          );
          notifyListeners();
        }
        // Fetch fresh data to confirm
        await fetchSensorData();
      }
      return success;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  // Save threshold settings
  Future<bool> saveThresholds(double tempThreshold, double humThreshold) async {
    try {
      _error = null;
      final success = await _apiService.saveThresholds(tempThreshold, humThreshold);
      if (success) {
        _tempThreshold = tempThreshold;
        _humThreshold = humThreshold;
        notifyListeners();
      }
      return success;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  // Toggle auto control
  void toggleAutoControl() {
    _autoControlEnabled = !_autoControlEnabled;
    notifyListeners();
  }

  // Get stored historical data
  Future<List<SensorData>> getStoredData() async {
    try {
      _error = null;
      return await _apiService.getStoredData();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return [];
    }
  }

  // Export data as CSV
  Future<String?> exportData() async {
    try {
      _error = null;
      return await _apiService.exportData();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return null;
    }
  }

  // Clear error
  void clearError() {
    _error = null;
    notifyListeners();
  }

  // Refresh data manually
  Future<void> refresh() async {
    await fetchSensorData();
  }
}
