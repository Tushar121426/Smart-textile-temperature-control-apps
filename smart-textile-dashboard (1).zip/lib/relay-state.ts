// Shared relay state across all API endpoints
export let relayState = false

export function setRelayState(state: boolean) {
  relayState = state
}

export function getRelayState() {
  return relayState
}
