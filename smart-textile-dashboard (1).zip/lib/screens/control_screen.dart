import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/sensor_provider.dart';
import '../theme/app_theme.dart';
import '../utils/constants.dart';

class ControlScreen extends StatefulWidget {
  const ControlScreen({super.key});

  @override
  State<ControlScreen> createState() => _ControlScreenState();
}

class _ControlScreenState extends State<ControlScreen> {
  final _tempController = TextEditingController();
  final _humController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    final provider = context.read<SensorProvider>();
    _tempController.text = provider.tempThreshold.toString();
    _humController.text = provider.humThreshold.toString();
  }

  @override
  void dispose() {
    _tempController.dispose();
    _humController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        await context.read<SensorProvider>().refresh();
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Temperature Control System',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildRelayControlSection(),
            const SizedBox(height: 20),
            _buildAutomaticControlSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildRelayControlSection() {
    return Consumer<SensorProvider>(
      builder: (context, provider, child) {
        final data = provider.currentData;
        final isConnected = provider.isConnected;
        final relayStatus = data?.relay ?? false;

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.power,
                      color: relayStatus ? AppTheme.primaryGreen : Colors.grey,
                      size: 24,
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'Manual Relay Control',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: relayStatus 
                        ? AppTheme.primaryGreen.withOpacity(0.1)
                        : Colors.grey.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: relayStatus 
                          ? AppTheme.primaryGreen
                          : Colors.grey,
                      width: 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: relayStatus 
                              ? AppTheme.primaryGreen
                              : Colors.grey,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Current Status: ${relayStatus ? 'ON' : 'OFF'}',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: relayStatus 
                              ? AppTheme.primaryGreen
                              : Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: isConnected && !_isLoading
                            ? () => _controlRelay(true)
                            : null,
                        icon: const Icon(Icons.power_settings_new),
                        label: const Text('Turn Peltier ON'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primaryGreen,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: isConnected && !_isLoading
                            ? () => _controlRelay(false)
                            : null,
                        icon: const Icon(Icons.power_off),
                        label: const Text('Turn Peltier OFF'),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ],
                ),
                if (!isConnected)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text(
                      'Device not connected. Manual control unavailable.',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 12,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildAutomaticControlSection() {
    return Consumer<SensorProvider>(
      builder: (context, provider, child) {
        final autoEnabled = provider.autoControlEnabled;

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.tune,
                        color: autoEnabled ? AppTheme.primaryGreen : Colors.grey,
                        size: 24,
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'Automatic Control Thresholds',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _tempController,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          decoration: const InputDecoration(
                            labelText: 'Temperature Threshold',
                            suffixText: '°C',
                            helperText: 'Relay activates above this temp',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Required';
                            }
                            final temp = double.tryParse(value);
                            if (temp == null) {
                              return 'Invalid number';
                            }
                            if (temp < AppConstants.minTemp || temp > AppConstants.maxTemp) {
                              return 'Range: ${AppConstants.minTemp}-${AppConstants.maxTemp}°C';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: TextFormField(
                          controller: _humController,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          decoration: const InputDecoration(
                            labelText: 'Humidity Threshold',
                            suffixText: '%',
                            helperText: 'Relay activates above this humidity',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Required';
                            }
                            final hum = double.tryParse(value);
                            if (hum == null) {
                              return 'Invalid number';
                            }
                            if (hum < AppConstants.minHumidity || hum > AppConstants.maxHumidity) {
                              return 'Range: ${AppConstants.minHumidity}-${AppConstants.maxHumidity}%';
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _isLoading ? null : _saveThresholds,
                          icon: _isLoading 
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.save),
                          label: Text(_isLoading ? 'Saving...' : 'Save Thresholds'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: provider.toggleAutoControl,
                          icon: Icon(
                            autoEnabled ? Icons.toggle_on : Icons.toggle_off,
                            color: autoEnabled ? AppTheme.primaryGreen : Colors.grey,
                          ),
                          label: Text(
                            autoEnabled ? 'Disable Auto' : 'Enable Auto',
                          ),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: autoEnabled 
                                ? AppTheme.primaryGreen 
                                : Colors.grey,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: autoEnabled 
                          ? AppTheme.primaryGreen.withOpacity(0.1)
                          : Colors.grey.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          autoEnabled ? Icons.check_circle : Icons.cancel,
                          color: autoEnabled ? AppTheme.primaryGreen : Colors.grey,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Auto control: ${autoEnabled ? 'ON' : 'OFF'}',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: autoEnabled ? AppTheme.primaryGreen : Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (autoEnabled)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'Relay will automatically turn ON when temperature ≥ ${provider.tempThreshold}°C or humidity ≥ ${provider.humThreshold}%',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _controlRelay(bool state) async {
    setState(() {
      _isLoading = true;
    });

    try {
      final provider = context.read<SensorProvider>();
      final success = await provider.controlRelay(state);
      
      if (mounted) {
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Relay turned ${state ? 'ON' : 'OFF'} successfully'),
              backgroundColor: AppTheme.primaryGreen,
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Failed to control relay'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _saveThresholds() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final tempThreshold = double.parse(_tempController.text);
      final humThreshold = double.parse(_humController.text);
      
      final provider = context.read<SensorProvider>();
      final success = await provider.saveThresholds(tempThreshold, humThreshold);
      
      if (mounted) {
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Thresholds saved successfully'),
              backgroundColor: AppTheme.primaryGreen,
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Failed to save thresholds'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
}
