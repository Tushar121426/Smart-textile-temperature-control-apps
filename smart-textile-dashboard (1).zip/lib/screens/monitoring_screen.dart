import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/sensor_provider.dart';
import '../widgets/sensor_chart.dart';

class MonitoringScreen extends StatelessWidget {
  const MonitoringScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        await context.read<SensorProvider>().refresh();
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Temperature & Humidity Monitoring',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Consumer<SensorProvider>(
              builder: (context, provider, child) {
                final data = provider.currentData;
                final isLoading = provider.isLoading;

                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildSensorRow(
                          'DS18B20 Temp',
                          isLoading ? '--' : '${data?.ds18b20.toStringAsFixed(1) ?? '--'}',
                          '°C',
                          Icons.thermostat,
                          Colors.red,
                        ),
                        const Divider(),
                        _buildSensorRow(
                          'DHT22 Temp',
                          isLoading ? '--' : '${data?.dhtTemp.toStringAsFixed(1) ?? '--'}',
                          '°C',
                          Icons.device_thermostat,
                          Colors.orange,
                        ),
                        const Divider(),
                        _buildSensorRow(
                          'DHT22 Humidity',
                          isLoading ? '--' : '${data?.dhtHum.toStringAsFixed(1) ?? '--'}',
                          '%',
                          Icons.water_drop,
                          Colors.blue,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 16),
            const Text(
              'Historical Chart',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Card(
              child: const SensorChart(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSensorRow(
    String label,
    String value,
    String unit,
    IconData icon,
    Color color,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Text(
            '$value $unit',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
