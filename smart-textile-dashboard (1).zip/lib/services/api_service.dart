import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/sensor_data.dart';

class ApiService {
  // Change this to your server URL
  static const String baseUrl = 'http://192.168.1.100:3000'; // Update with your server IP
  static const Duration timeout = Duration(seconds: 10);

  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  // Get sensor readings with history
  Future<SensorData> getReadings() async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/api/readings'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(timeout);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return SensorData.fromJson(data);
      } else {
        throw ApiException('Failed to fetch readings: ${response.statusCode}');
      }
    } on SocketException {
      throw ApiException('No internet connection');
    } on http.ClientException {
      throw ApiException('Connection failed');
    } catch (e) {
      throw ApiException('Error fetching readings: $e');
    }
  }

  // Control relay (manual override)
  Future<bool> setRelay(bool state) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/api/relay'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({'relay': state}),
          )
          .timeout(timeout);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['success'] == true;
      } else {
        throw ApiException('Failed to control relay: ${response.statusCode}');
      }
    } on SocketException {
      throw ApiException('No internet connection');
    } on http.ClientException {
      throw ApiException('Connection failed');
    } catch (e) {
      throw ApiException('Error controlling relay: $e');
    }
  }

  // Save temperature and humidity thresholds
  Future<bool> saveThresholds(double tempThreshold, double humThreshold) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/api/thresholds'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({
              'temp': tempThreshold,
              'hum': humThreshold,
            }),
          )
          .timeout(timeout);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['success'] == true;
      } else {
        throw ApiException('Failed to save thresholds: ${response.statusCode}');
      }
    } on SocketException {
      throw ApiException('No internet connection');
    } on http.ClientException {
      throw ApiException('Connection failed');
    } catch (e) {
      throw ApiException('Error saving thresholds: $e');
    }
  }

  // Get stored historical data
  Future<List<SensorData>> getStoredData() async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/api/stored'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(timeout);

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((item) => SensorData.fromJson(item)).toList();
      } else {
        throw ApiException('Failed to fetch stored data: ${response.statusCode}');
      }
    } on SocketException {
      throw ApiException('No internet connection');
    } on http.ClientException {
      throw ApiException('Connection failed');
    } catch (e) {
      throw ApiException('Error fetching stored data: $e');
    }
  }

  // Export data as CSV
  Future<String> exportData() async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/api/export'),
            headers: {'Accept': 'text/csv'},
          )
          .timeout(timeout);

      if (response.statusCode == 200) {
        return response.body;
      } else {
        throw ApiException('Failed to export data: ${response.statusCode}');
      }
    } on SocketException {
      throw ApiException('No internet connection');
    } on http.ClientException {
      throw ApiException('Connection failed');
    } catch (e) {
      throw ApiException('Error exporting data: $e');
    }
  }
}

class ApiException implements Exception {
  final String message;
  ApiException(this.message);

  @override
  String toString() => 'ApiException: $message';
}
