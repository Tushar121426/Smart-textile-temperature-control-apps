class AppConstants {
  // API Configuration
  static const String defaultServerUrl = 'http://192.168.1.100:3000';
  static const Duration apiTimeout = Duration(seconds: 10);
  static const Duration pollingInterval = Duration(seconds: 5);

  // Sensor thresholds
  static const double defaultTempThreshold = 30.0;
  static const double defaultHumThreshold = 70.0;

  // Chart configuration
  static const int maxHistoryPoints = 50;
  static const double chartHeight = 200.0;

  // UI Constants
  static const double cardPadding = 16.0;
  static const double sectionSpacing = 20.0;
  static const double borderRadius = 12.0;

  // Temperature and humidity ranges for validation
  static const double minTemp = -40.0;
  static const double maxTemp = 80.0;
  static const double minHumidity = 0.0;
  static const double maxHumidity = 100.0;
}
