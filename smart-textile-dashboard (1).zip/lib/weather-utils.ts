// Utility functions for weather data processing

export interface WeatherData {
  location: string
  temperature: number
  condition: string
  description: string
  timestamp: string
  source: string
  humidity?: number
  pressure?: number
  windSpeed?: number
  error?: boolean
}

export function getWeatherIcon(condition: string): string {
  const iconMap: Record<string, string> = {
    clear: "☀️",
    clouds: "☁️",
    rain: "🌧️",
    drizzle: "🌦️",
    thunderstorm: "⛈️",
    snow: "❄️",
    mist: "🌫️",
    fog: "🌫️",
    haze: "🌫️",
    dust: "🌪️",
    sand: "🌪️",
    ash: "🌋",
    squall: "💨",
    tornado: "🌪️",
  }

  return iconMap[condition.toLowerCase()] || "🌤️"
}

export function getWeatherColor(condition: string): string {
  const colorMap: Record<string, string> = {
    clear: "text-yellow-600",
    clouds: "text-gray-600",
    rain: "text-blue-600",
    drizzle: "text-blue-500",
    thunderstorm: "text-purple-600",
    snow: "text-blue-200",
    mist: "text-gray-500",
    fog: "text-gray-500",
    haze: "text-gray-500",
  }

  return colorMap[condition.toLowerCase()] || "text-green-600"
}

export function isWeatherDataStale(timestamp: string, maxAgeMinutes = 10): boolean {
  const dataTime = new Date(timestamp).getTime()
  const now = Date.now()
  const maxAge = maxAgeMinutes * 60 * 1000

  return now - dataTime > maxAge
}
