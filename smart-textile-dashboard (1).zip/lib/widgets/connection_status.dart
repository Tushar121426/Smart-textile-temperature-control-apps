import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/sensor_provider.dart';

class ConnectionStatus extends StatelessWidget {
  const ConnectionStatus({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SensorProvider>(
      builder: (context, provider, child) {
        final isConnected = provider.isConnected;
        final isLoading = provider.isLoading;

        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: isLoading
                ? Colors.orange.withOpacity(0.2)
                : isConnected
                    ? Colors.green.withOpacity(0.2)
                    : Colors.red.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: isLoading
                      ? Colors.orange
                      : isConnected
                          ? Colors.green
                          : Colors.red,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                isLoading
                    ? 'Connecting...'
                    : isConnected
                        ? 'Connected'
                        : 'Disconnected',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: isLoading
                      ? Colors.orange
                      : isConnected
                          ? Colors.green
                          : Colors.red,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
