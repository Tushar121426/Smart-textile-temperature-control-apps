import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/sensor_provider.dart';
import '../theme/app_theme.dart';

class OverviewCards extends StatelessWidget {
  const OverviewCards({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SensorProvider>(
      builder: (context, provider, child) {
        final data = provider.currentData;
        final isLoading = provider.isLoading;

        return Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: _buildCard(
                    context,
                    'Current Temperature',
                    isLoading ? '--' : '${data?.ds18b20.toStringAsFixed(1) ?? '--'}',
                    '°C',
                    Icons.thermostat,
                    AppTheme.primaryGreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildCard(
                    context,
                    'Current Humidity',
                    isLoading ? '--' : '${data?.dhtHum.toStringAsFixed(1) ?? '--'}',
                    '%',
                    Icons.water_drop,
                    Colors.blue,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildCard(
              context,
              'Relay Status',
              isLoading ? 'Unknown' : (data?.relay == true ? 'ON' : 'OFF'),
              '',
              Icons.power,
              data?.relay == true ? AppTheme.primaryGreen : Colors.grey,
              fullWidth: true,
            ),
          ],
        );
      },
    );
  }

  Widget _buildCard(
    BuildContext context,
    String title,
    String value,
    String unit,
    IconData icon,
    Color color, {
    bool fullWidth = false,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: fullWidth ? CrossAxisAlignment.center : CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: fullWidth ? MainAxisAlignment.center : MainAxisAlignment.start,
              children: [
                Icon(
                  icon,
                  color: color,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey,
                    ),
                    textAlign: fullWidth ? TextAlign.center : TextAlign.start,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            RichText(
              textAlign: fullWidth ? TextAlign.center : TextAlign.start,
              text: TextSpan(
                children: [
                  TextSpan(
                    text: value,
                    style: TextStyle(
                      fontSize: fullWidth ? 24 : 28,
                      fontWeight: FontWeight.bold,
                      color: color,
                      fontFamily: 'Inter',
                    ),
                  ),
                  if (unit.isNotEmpty)
                    TextSpan(
                      text: ' $unit',
                      style: TextStyle(
                        fontSize: fullWidth ? 16 : 18,
                        fontWeight: FontWeight.w500,
                        color: Colors.grey,
                        fontFamily: 'Inter',
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
