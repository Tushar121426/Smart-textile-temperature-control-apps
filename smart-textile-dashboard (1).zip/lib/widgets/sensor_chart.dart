import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../providers/sensor_provider.dart';
import '../models/sensor_data.dart';

class SensorChart extends StatelessWidget {
  const SensorChart({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SensorProvider>(
      builder: (context, provider, child) {
        final data = provider.currentData;
        final history = data?.history ?? [];

        if (history.isEmpty) {
          return Container(
            height: 200,
            padding: const EdgeInsets.all(16),
            child: const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.show_chart,
                    size: 48,
                    color: Colors.grey,
                  ),
                  SizedBox(height: 8),
                  Text(
                    'No historical data available',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          );
        }

        return Container(
          height: 250,
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Legend
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildLegendItem('DS18B20 (°C)', Colors.red),
                  _buildLegendItem('DHT Temp (°C)', Colors.orange),
                  _buildLegendItem('Humidity (%)', Colors.blue),
                ],
              ),
              const SizedBox(height: 16),
              // Chart
              Expanded(
                child: LineChart(
                  _buildChartData(history),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLegendItem(String label, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 12,
          height: 2,
          color: color,
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  LineChartData _buildChartData(List<HistoryPoint> history) {
    // Take last 20 points for better visibility
    final displayHistory = history.length > 20 
        ? history.sublist(history.length - 20) 
        : history;

    // Find min/max values for scaling
    double minTemp = double.infinity;
    double maxTemp = double.negativeInfinity;
    
    for (final point in displayHistory) {
      minTemp = [minTemp, point.ds, point.dt].reduce((a, b) => a < b ? a : b);
      maxTemp = [maxTemp, point.ds, point.dt].reduce((a, b) => a > b ? a : b);
    }

    // Add some padding to the range
    final tempRange = maxTemp - minTemp;
    minTemp -= tempRange * 0.1;
    maxTemp += tempRange * 0.1;

    return LineChartData(
      gridData: FlGridData(
        show: true,
        drawVerticalLine: true,
        horizontalInterval: (maxTemp - minTemp) / 4,
        verticalInterval: displayHistory.length > 1 ? displayHistory.length / 4 : 1,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: Colors.grey.withOpacity(0.3),
            strokeWidth: 1,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: Colors.grey.withOpacity(0.3),
            strokeWidth: 1,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        rightTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 40,
            interval: 20,
            getTitlesWidget: (value, meta) {
              return Text(
                '${value.toInt()}%',
                style: const TextStyle(
                  color: Colors.blue,
                  fontWeight: FontWeight.bold,
                  fontSize: 10,
                ),
              );
            },
          ),
        ),
        topTitles: const AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            interval: (maxTemp - minTemp) / 4,
            reservedSize: 40,
            getTitlesWidget: (value, meta) {
              return Text(
                '${value.toStringAsFixed(1)}°C',
                style: const TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontSize: 10,
                ),
              );
            },
          ),
        ),
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 30,
            interval: displayHistory.length > 1 ? displayHistory.length / 4 : 1,
            getTitlesWidget: (value, meta) {
              final index = value.toInt();
              if (index >= 0 && index < displayHistory.length) {
                final time = DateTime.fromMillisecondsSinceEpoch(displayHistory[index].ts);
                return Text(
                  '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}',
                  style: const TextStyle(
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                    fontSize: 10,
                  ),
                );
              }
              return const Text('');
            },
          ),
        ),
      ),
      borderData: FlBorderData(
        show: true,
        border: Border.all(color: Colors.grey.withOpacity(0.3)),
      ),
      minX: 0,
      maxX: (displayHistory.length - 1).toDouble(),
      minY: minTemp,
      maxY: maxTemp,
      lineBarsData: [
        // DS18B20 Temperature
        LineChartBarData(
          spots: displayHistory.asMap().entries.map((entry) {
            return FlSpot(entry.key.toDouble(), entry.value.ds);
          }).toList(),
          isCurved: true,
          color: Colors.red,
          barWidth: 2,
          isStrokeCapRound: true,
          dotData: const FlDotData(show: false),
          belowBarData: BarAreaData(show: false),
        ),
        // DHT22 Temperature
        LineChartBarData(
          spots: displayHistory.asMap().entries.map((entry) {
            return FlSpot(entry.key.toDouble(), entry.value.dt);
          }).toList(),
          isCurved: true,
          color: Colors.orange,
          barWidth: 2,
          isStrokeCapRound: true,
          dotData: const FlDotData(show: false),
          belowBarData: BarAreaData(show: false),
        ),
        // Humidity (scaled to temperature range for display)
        LineChartBarData(
          spots: displayHistory.asMap().entries.map((entry) {
            // Scale humidity (0-100) to temperature range for visualization
            final scaledHumidity = minTemp + (entry.value.dh / 100) * (maxTemp - minTemp);
            return FlSpot(entry.key.toDouble(), scaledHumidity);
          }).toList(),
          isCurved: true,
          color: Colors.blue,
          barWidth: 2,
          isStrokeCapRound: true,
          dotData: const FlDotData(show: false),
          belowBarData: BarAreaData(show: false),
        ),
      ],
      lineTouchData: LineTouchData(
        enabled: true,
        touchTooltipData: LineTouchTooltipData(
          tooltipBgColor: Colors.blueGrey.withOpacity(0.8),
          getTooltipItems: (List<LineBarSpot> touchedBarSpots) {
            return touchedBarSpots.map((barSpot) {
              final index = barSpot.x.toInt();
              if (index >= 0 && index < displayHistory.length) {
                final point = displayHistory[index];
                final time = DateTime.fromMillisecondsSinceEpoch(point.ts);
                
                switch (barSpot.barIndex) {
                  case 0:
                    return LineTooltipItem(
                      'DS18B20: ${point.ds.toStringAsFixed(1)}°C\n${time.hour}:${time.minute.toString().padLeft(2, '0')}',
                      const TextStyle(color: Colors.white),
                    );
                  case 1:
                    return LineTooltipItem(
                      'DHT Temp: ${point.dt.toStringAsFixed(1)}°C\n${time.hour}:${time.minute.toString().padLeft(2, '0')}',
                      const TextStyle(color: Colors.white),
                    );
                  case 2:
                    return LineTooltipItem(
                      'Humidity: ${point.dh.toStringAsFixed(1)}%\n${time.hour}:${time.minute.toString().padLeft(2, '0')}',
                      const TextStyle(color: Colors.white),
                    );
                  default:
                    return null;
                }
              }
              return null;
            }).toList();
          },
        ),
      ),
    );
  }
}
